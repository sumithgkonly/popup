function menuIcon(){
	document.getElementById("navbar-toggle").style.display="block";
}

function close_navbar(){
	document.getElementById("navbar-toggle").style.display="none";
}
function checkbox(e){
	var id = e.id;
	var flag = document.getElementById('checkbox-'+id).checked;
	var children = e.childNodes;
	var child;
	for (var i = 0; i < children.length; i++) {
		if(children[i].className == 'checkbox_inner'){
			child = children[i];
		}
	}

	if (flag) {
		document.getElementById('checkbox-'+id).checked = false;
		child.style.background = 'rgb(216, 216, 216)';
	}else{
		document.getElementById('checkbox-'+id).checked = true;	
		child.style.background = 'rgb(60, 177, 230)';	
	}
}

window.onload = function() {
	var checkboxes = document.getElementsByClassName("checkbox_outer");
	for(i=0;i<checkboxes.length;i++){
		checkboxes[i].addEventListener('click',function() {
			checkbox(this);
		});
	}
}

